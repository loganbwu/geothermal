
import numpy as np
from openpyxl import load_workbook 	# openpyxl is a package I had to download
import os
from matplotlib import pyplot as plt
from scikits import bootstrap # scikits.bootstrap is a package I had to download

textsize = 13
years = ['2012',]
z = 1.
z = 1.96

pmin, pmean, pmax = [5,50,95]

class student(object):
	def __init__(self):
		self.id = None
		self.assignments = []
		self.exam = None
		self.test = None
		self.N = 0

for year in years:
#year = '2014'

	N_assignments = 2

	try: del student_list
	except: pass

	try: student_list
	except: 

		for i in range(1,N_assignments+1):
			# load workbook
			wb = load_workbook(year+os.sep+'Assignment%i_anon.xlsx'%i)
			
			# cycle through and save assignment number
			ids = list(wb.active.columns)[2]
			marks = list(wb.active.columns)[4]
			
			# create student_list dictionary if it doesn't already exist
			try: student_list
			except:
				student_list = []
				for id in ids[1:]:
					student_list.append([int(id.value), student()])
				student_list = dict(student_list)
				
			for id, mark in zip(ids[1:], marks[1:]):
				if mark.value is not None: 
					mark = mark.value*1.
				else:
					mark = None
				student_list[int(id.value)].assignments.append(mark)

		# load in term test marks
		wb = load_workbook(year+os.sep+'Test_anon.xlsx')
		ids = list(wb.active.columns)[2]
		marks = list(wb.active.columns)[4]
		for id, mark in zip(ids[1:], marks[1:]):
			if mark.value is not None: 
				mark = mark.value*1.
			else:
				mark = None
			student_list[int(id.value)].test = mark

		# load in exam marks
		wb = load_workbook(year+os.sep+'Exam_anon.xlsx')
		ids = list(wb.active.columns)[2]
		marks = list(wb.active.columns)[4]
		for id, mark in zip(ids[1:], marks[1:]):
			if mark.value is not None: 
				mark = mark.value*1.
			else:
				mark = None
			student_list[int(id.value)].exam = mark

		# count up number of assignments completed
		for k in student_list.keys(): 
			s = student_list[k]
			for assignment in s.assignments: 
				if assignment is not None: 
					s.N += 1
				
	fig = plt.figure()
	ax = plt.axes([0.15,0.15,0.7,0.7])

	em = []; es = []; ep = []
	tm = []; ts = []; tp = []
	ks = student_list.keys()
	for i in range(N_assignments+1):
		ei = []
		ti = []
		for k in ks:
			s = student_list[k]
			if None in [s.exam, s.test]: continue
			if s.N>= i:
				ei.append(s.exam/120.*100.)
				ti.append(s.test/60.*100.)
				
		if len(ei) == 0:
			em.append(None)
			es.append(None)
			ep.append(None)
			tm.append(None)
			ts.append(None)
			tp.append(None)
			continue
		
		esi = np.mean(ei)
		emi,epi = bootstrap.ci(ei)
		em.append(emi)
		es.append(esi)
		ep.append(epi)
		
		tsi = np.mean(ti)
		tmi,tpi = bootstrap.ci(ti)
		tm.append(tmi)
		ts.append(tsi)
		tp.append(tpi)
		
	a = range(N_assignments+1)

	for ai, tmi, tsi, tpi in zip(a, tm, ts, tp):
		continue
		ax.plot(ai, tsi, 'bs')
		ax.plot([ai, ai], [tmi,tpi], 'b-')

	for ai, tmi, tsi, tpi in zip(a, em, es, ep):
		ax.plot(ai, tsi, 'ks')
		ax.plot([ai, ai], [tmi,tpi], 'k-')

	ax.set_xlim([-0.2,9.2])
	ax.set_xlabel('minimum number of completed assignments', size = textsize)
	ax.set_ylabel('average exam mark', size = textsize)

	ax.set_title('%s: exam mark vs. assignment completion'%year, size = textsize)
	
	for t in ax.get_xticklabels()+ax.get_yticklabels():
		t.set_fontsize(textsize)
		
	plt.savefig('analytics_%s.png'%year)
	

		
		
		
		
		